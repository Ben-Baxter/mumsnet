BACKUP DATABASE [AssignmentPart1] TO  DISK = N'C:\Users\Public\AssignmentPart1_no_nulls_no_dup.bak' WITH NOFORMAT, NOINIT,  NAME = N'AssignmentPart1-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
