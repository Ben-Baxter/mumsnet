BACKUP DATABASE [mumsnet] TO  DISK = N'C:\Users\Public\mumsnet_v8.bak' WITH NOFORMAT, NOINIT,  NAME = N'mumsnet-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO
