use mumsnet;
select * 
  from information_schema.routines 
 where routine_type = 'PROCEDURE'